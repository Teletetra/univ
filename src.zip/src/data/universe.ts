export type PlanetConfig = {
  id: string;
  chapter: string;
  name: string;
  subtitle: string;
  description: string;
  color: string;
  emissive: string;
  size: number;
  orbitRadius: number;
  orbitSpeed: number;
  orbitInclination: number;
  href: string;
  achievement?: string;
};

export const RITU_STAR = {
  name: "Ritu",
  designation: "RITU-001",
  birthday: "19 · NOV",
  subtitle: "Principal Investigator",
} as const;

export const PLANETS: PlanetConfig[] = [
  {
    id: "wave-mechanics",
    chapter: "01",
    name: "Wave Mechanics",
    subtitle: "The Double-Slit Experiment",
    description:
      "The universe has an extraordinary number of possibilities. Somehow, one of my favourite discoveries was getting to know you.",
    color: "#5b5fc7",
    emissive: "#9485ed",
    size: 0.7,
    orbitRadius: 5.5,
    orbitSpeed: 0.18,
    orbitInclination: 0.1,
    href: "/experiments/double-slit",
    achievement: "OBSERVER EFFECT · FIRST LOOK",
  },
  {
    id: "entanglement",
    chapter: "02",
    name: "Entanglement",
    subtitle: "Quantum Correlations",
    description:
      "Some connections are difficult to explain. Not because they aren't real, but because ordinary language sometimes feels too small.",
    color: "#4ec9d6",
    emissive: "#7ee3ee",
    size: 0.6,
    orbitRadius: 7.2,
    orbitSpeed: 0.13,
    orbitInclination: -0.08,
    href: "/experiments/entanglement",
    achievement: "PLAYER 2 HAS JOINED",
  },
  {
    id: "probability",
    chapter: "03",
    name: "Probability",
    subtitle: "The Probability of You",
    description:
      "If I had to choose what to spend more time discovering, it would still be you.",
    color: "#d6b99a",
    emissive: "#f0d5b6",
    size: 0.75,
    orbitRadius: 9.4,
    orbitSpeed: 0.09,
    orbitInclination: 0.14,
    href: "/experiments/probability",
    achievement: "OBSERVER BIAS · STRONGLY FAVOURABLE",
  },
  {
    id: "archive",
    chapter: "04",
    name: "The Archive",
    subtitle: "Observation Archive",
    description:
      "Every little detail, remembered. Some things deserve to be appreciated.",
    color: "#b56bd1",
    emissive: "#d8a4f0",
    size: 0.65,
    orbitRadius: 11.8,
    orbitSpeed: 0.065,
    orbitInclination: -0.15,
    href: "/archive",
    achievement: "DATA INTEGRITY · PERFECT",
  },
  {
    id: "final",
    chapter: "05",
    name: "Final Report",
    subtitle: "An Observation Beyond Measurement",
    description:
      "Not everything beautiful needs an explanation. Some things deserve to be appreciated.",
    color: "#e8ddf8",
    emissive: "#ffffff",
    size: 0.45,
    orbitRadius: 14.2,
    orbitSpeed: 0.045,
    orbitInclination: 0.05,
    href: "/final-report",
    achievement: "MISSION COMPLETE · BEGINNING OF SOMETHING ELSE",
  },
];