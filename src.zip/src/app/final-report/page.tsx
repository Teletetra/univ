import AppShell from "@/components/shell/AppShell";
import { FINAL_LETTER } from "@/data/letters";

export default function Page() {
  return (
    <AppShell active="Final report">
      <p className="lab-label">Personal research archive · Final report</p>
      <h1 className="mt-2 font-serif text-3xl md:text-4xl">
        An Observation Beyond Measurement
      </h1>
      <p className="mt-4 max-w-2xl font-hand text-lg leading-8 text-[#e8ddf8] whitespace-pre-line">
        {FINAL_LETTER}
      </p>
    </AppShell>
  );
}