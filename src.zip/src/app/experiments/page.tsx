import AppShell from "@/components/shell/AppShell";

export default function Page() {
  return (
    <AppShell active="Experiments">
      <h1 className="font-serif text-3xl">Experiments</h1>
      <p className="mt-2 text-sm text-[#929fbd]">
        Chapter list coming next.
      </p>
    </AppShell>
  );
}