import AppShell from "@/components/shell/AppShell";

export default function Page() {
  return (
    <AppShell active="Experiments">
      <h1 className="font-serif text-3xl">The Probability of You</h1>
      <p className="mt-2 text-sm text-[#929fbd]">
        Experiment UI coming next.
      </p>
    </AppShell>
  );
}