import AppShell from "@/components/shell/AppShell";

export default function Page() {
  return (
    <AppShell active="Observation archive">
      <h1 className="font-serif text-3xl">Observation Archive</h1>
      <p className="mt-2 text-sm text-[#929fbd]">
        Memory archive coming next.
      </p>
    </AppShell>
  );
}